<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_oauthclient
 *
 * 
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */


// No direct access to this file
defined('_JEXEC') or die('Restricted access');
JHtml::stylesheet(JURI::base() . 'components/com_oauthclient/assets/css/oauthstyles.css', array());

$active_tab = 'oauthConfig';

$get = JFactory::getApplication()->input->get->getArray();


if (isset($get['tab']) && !empty($get['tab'])) {
    $active_tab = $get['tab'];
}

?>

<html>

<body>
    <div style="padding:1rem;">

        <div class="wrap">

            <h2 class="nav-tab-wrapper" style="border:none;">
                <a href="#oauthconfig" class="nav-tab <?php echo $active_tab == 'oauthConfig' ? 'nav-tab-active' : ''; ?>" style="background-color:#ccc;border:1px solid #ccc; padding:5px;font-size:18px;">Configuration</a>
                <a href="#oauthHelp" class="nav-tab <?php echo $active_tab == 'oauthHelp' ? 'nav-tab-active' : ''; ?>" style="background-color:#ccc;border:1px solid #ccc;padding:5px;font-size:18px;">Help</a>

            </h2>
        </div>
        <div>
            <div id="oauthconfig">
                <?php echo oauthClient_Config(); ?>
            </div>
            <div id="oauthHelp">
                <?php echo oauthClient_Help(); ?>
            </div>
        </div>
        <?php
        function oauthClient_Config()
        {
            $oauth_config_values = DatabaseHandler::retrive_db_fields('#__oauth_client_settings', '*', 'id', 1, 0, 'loadobjectlist');
            $oauth_attribute_config = DatabaseHandler::retrive_db_fields('#__oauth_attributeconfig', '*', 'id', 1, 0, 'loadobjectlist');

        ?>
            <div class="oauthclient_outerdiv">
                <div>
                    <h3>oAuth Configuration</h3>
                </div>


                <div class="oauthclient_innerdiv">
                    <form method="post" action="<?php echo JRoute::_('index.php?option=com_oauthclient&view=oauthclientview&task=oauthclientconfig.oauthconfig'); ?>">
                        <label class="oauthclient_configlabel">App Name:</label>
                        <input class="oauthclient_configinput" id="app_name" name="app_name" type="text" value="<?php if( isset($oauth_config_values['appname']) )echo $oauth_config_values['appname']; else echo ' ';?>"/>
                        <label class="oauthclient_configlabel">CallBack URL:</label>
                        <input id="callback_url" name="callback_url" type="text" class="oauthclient_configinput" disabled value="<?php echo JURI::root(); ?>" />
                        <label class="oauthclient_configlabel">Client ID/ Application ID:</label>
                        <input id="client_id" name="client_id" type="text" class="oauthclient_configinput" value="<?php if( isset($oauth_config_values['client_id']) )echo $oauth_config_values['client_id']; else echo ' '; ?>" />
                        <label class="oauthclient_configlabel">Client Secret:</label>
                        <input id="client_secret" name="client_secret" type="text" class="oauthclient_configinput" value="<?php if( isset($oauth_config_values['client_secret']) )echo $oauth_config_values['client_secret']; else echo ' '; ?>"/>
                        <label class="oauthclient_configlabel">Scope:</label>
                        <input id="clientScope" name="clientScope" type="text" class="oauthclient_configinput"  value="<?php if( isset($oauth_config_values['oauth_scope']) )echo $oauth_config_values['oauth_scope']; else echo ' '; ?>"/><br />
                        <input class="oauthclient_configsave" type="submit" value="Save Configuration" />
                        <!-- <label style="float:left; padding-right:1rem;">Scope:</label>
                         <input id="scope" type="text" /> -->
                    </form>
                </div>


            </div>


            <div class="oauthclient_attrMapdiv">
                <div>
                    <h3> Configure Attribute Mapping</h3>
                </div>
                <div class="oauthclient_innerdiv">
                    <form method="post" action="<?php echo JRoute::_('index.php?option=com_oauthclient&view=oauthclientview&task=oauthclientconfig.attributeconfig'); ?>">
                        <label class="oauthclient_configlabel">email:</label>
                        <input class="oauthclient_configinput" id="uemail" name="uemail" type="text" value="<?php if( isset($oauth_attribute_config['useremail']) )echo $oauth_attribute_config['useremail']; else echo ' '; ?>"/>
                        <label class="oauthclient_configlabel">username:</label>
                        <input class="oauthclient_configinput" id="uname" name='uname' type="text" value="<?php if( isset($oauth_attribute_config['username']) )echo $oauth_attribute_config['username']; else echo ' ';?>" /><br />
                        <input type="submit" value="Save Attribute Mapping" />
                    </form>
                </div>

            </div>
        <?php }

        function oauthClient_Help()
        {
        }

        ?>

</body>

</html>