<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_oauthclient
 *
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');

class DatabaseHandler
{

   public static function save_db_fileds($db_name, $fields, $condition_name, $condition)
    {

        // Get a db connection.
        $db = JFactory::getDbo();
        // Create a new query object.
        $query = $db->getQuery(true);
        foreach ($fields as $x => $y)
        {
            $db_fileds[] = $db->quoteName($x) . ' = ' . $db->quote($y);
        }
        $condition = array(
            $db->quoteName($condition_name) . ' = ' . $db->quote($condition) ,

        );
        $query->update($db->quoteName($db_name))->set($db_fileds)->where($condition);
        $db->setQuery($query);
        $result = $db->execute();
    }

    public static function retrive_db_fields($db_name, $array_fields_to_retrive, $condition_name, $condition, $ordering_enabled, $loadresult)
    {

        

        // Get a db connection.
        $db = JFactory::getDbo();

        // Create a new query object.
        $query = $db->getQuery(true);


        if ($array_fields_to_retrive == '*')
        {

            $select_list = '*';
        }
        else
        {

            $select_list = $db->quoteName($array_fields_to_retrive);
        }
        // Select all records from the user profile table where key begins with "custom.".
        // Order it by the ordering field.
        $query->select($select_list);
        $query->from($db->quoteName($db_name));
        $condition = array(
            $db->quoteName($condition_name) . ' = ' . $db->quote($condition) ,

        );

        $query->where($condition);
        if ($ordering_enabled) $query->order('ordering ASC');

        // Reset the query using our newly populated query object.
        $db->setQuery($query);

        // Load the results as a list of stdClass objects (see later for more options on retrieving data).
        if ($loadresult == 'loadobjectlist') $results = $db->loadAssoc();

        return $results;

    }

}

