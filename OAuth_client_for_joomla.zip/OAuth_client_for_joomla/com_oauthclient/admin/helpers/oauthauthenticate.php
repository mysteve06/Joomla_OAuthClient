<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_oauthclient
 *
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');

class OAuthauthenticate
{

    public static function call_to_token_endpoint($token_endpoint_url, $redirect_uri, $client_id, $client_secret, $code, $grant_type)
    {

        
        $authorization = base64_encode("$client_id:$client_secret");
        $header = array("Authorization: Basic {$authorization}", "Content-Type: application/x-www-form-urlencoded");
        $content = "grant_type=".$grant_type."&code=".$code."&redirect_uri=".$redirect_uri;


        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $token_endpoint_url,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $content
        ));
        $response = curl_exec($curl);
      
        curl_close($curl);

        if ($response === false) {
            echo "Failed";
            echo curl_error($curl);
            echo "Failed";
        } elseif (isset(json_decode($response)->error)) {
            echo "Error:<br />";
            echo $code;
            echo $response;
        }

        return json_decode($response)->access_token;


    }

    public static function call_to_user_info_endpoint($userinfo_endpoint_url, $access_token){

        
        $header = array("Authorization: Bearer {$access_token}");
    
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $userinfo_endpoint_url,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_RETURNTRANSFER => true
        ));
        $response = curl_exec($curl);
        curl_close($curl);
    
     
        return json_decode($response, true);

    }


    public static function genratestate()
    {

        return 0;
    }
}
