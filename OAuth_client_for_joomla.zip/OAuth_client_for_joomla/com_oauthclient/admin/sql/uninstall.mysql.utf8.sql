DROP TABLE IF EXISTS `#__oauth_client_settings`;
DROP TABLE IF EXISTS `#__oauth_attributeconfig`;