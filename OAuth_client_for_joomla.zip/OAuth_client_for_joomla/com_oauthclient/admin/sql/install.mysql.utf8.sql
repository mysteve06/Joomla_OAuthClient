DROP TABLE IF EXISTS `#__oauth_client_settings`;
DROP TABLE IF EXISTS `#__oauth_attributeconfig`;

CREATE TABLE `#__oauth_client_settings` (
	`id` INT(1) UNSIGNED  NOT NULL DEFAULT '1',
	`appname` VARCHAR(255),
	`callback_uri` VARCHAR(255) ,
	`client_id` VARCHAR(255) ,
	`client_secret` VARCHAR(255),
	`oauth_scope` VARCHAR(255) ,
	`authorization_endpoint_url` VARCHAR(255) ,
	`token_endpoint_url` VARCHAR(255) ,
	`userinfo_endpoint_url` VARCHAR(255) ,
	`version` VARCHAR(15),
	
	PRIMARY KEY (`id`)
)
	ENGINE=InnoDB 
	DEFAULT CHARSET=utf8mb4 
	DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `#__oauth_attributeconfig` (
	`id` INT(1) UNSIGNED  NOT NULL DEFAULT '1', 
	`username` VARCHAR(255),
	`useremail` VARCHAR(255),
	
	
	PRIMARY KEY (`id`)
)
	ENGINE=InnoDB 
	DEFAULT CHARSET=utf8mb4 
	DEFAULT COLLATE=utf8mb4_unicode_ci;
	

INSERT INTO `#__oauth_client_settings` (`id`, `version`) VALUES ('1', '0.0.1');
INSERT INTO `#__oauth_attributeconfig` (`id`) VALUES ('1');