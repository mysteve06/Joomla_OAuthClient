<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_oauthclient
 *
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');

class OAuthClientControllerOauthclientconfig  extends JControllerForm
{

    function oauthconfig()
    {
        $post = JFactory::getApplication()->input->post->getArray();

        $connect = new DatabaseHandler();
        // Get a db connection.
        $db_name = '#__oauth_client_settings';

        $fields = array(
            'appname' => $post['app_name'],
            'callback_uri' => $post['callback_url'],
            'client_id' => trim($post['client_id']),
            'client_secret' => trim($post['client_secret']),
            'oauth_scope' => 'email profile',
            'authorization_endpoint_url' => 'https://accounts.google.com/o/oauth2/auth',
            'token_endpoint_url' => 'https://www.googleapis.com/oauth2/v3/token',
            'userinfo_endpoint_url' => 'https://www.googleapis.com/oauth2/v1/userinfo',
        );
        $condition_name = 'id';
        $condition = 1;

        $connect->save_db_fileds($db_name, $fields, $condition_name, $condition);

        $this->setRedirect('index.php?option=com_oauthclient&view=oauthclientview', 'Settings saved sucessfully.');
    }

    function attributeconfig()
    {

        $post = JFactory::getApplication()
            ->input
            ->post
            ->getArray();
        $connect = new DatabaseHandler();
        // Get a db connection.
        $db_name = '#__oauth_attributeconfig';

        $fields = array(
            'username' => $post['uname'],
            'useremail' => $post['uemail'],

        );
        $condition_name = 'id';
        $condition = 1;

        $connect->save_db_fileds($db_name, $fields, $condition_name, $condition);

        $this->setRedirect('index.php?option=com_oauthclient&view=oauthclientview', 'Settings saved sucessfully.');
    }
}
