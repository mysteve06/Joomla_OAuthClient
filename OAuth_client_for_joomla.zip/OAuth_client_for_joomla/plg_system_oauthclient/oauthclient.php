<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  plg_system_oauthclient
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.plugin.plugin');

require_once JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_oauthclient' . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'oauthauthenticate.php';
require_once JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_oauthclient' . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'database_handler.php';

class plgSystemOAuthClient extends JPlugin
{


    public function onAfterRoute()
    {

        $get = JFactory::getApplication()->input->get->getArray();


        if (isset($get['oauthclientlogin']) && ($get['oauthclientlogin'] == 'oauthlogin' || $get['oauthclientlogin'] == 'oauthlogin')) {


            $result = DatabaseHandler::retrive_db_fields('#__oauth_client_settings', '*', 'id', 1, 0, 'loadobjectlist');

            $auth_code_url = $result['authorization_endpoint_url'];
            $client_id = $result['client_id'];
            $scope = $result['oauth_scope'];
            $state = 'asdfghjklkjhgfdsa';

            $authorizationUrl = $auth_code_url . "?client_id=" . $client_id . "&scope=" . $scope . "&redirect_uri=" . JURI::root() . "&response_type=code&state=" . $state;

            if (session_id() == '' || !isset($session))
                session_start();

            header('Location: ' . $authorizationUrl);
            exit;
        }

        //Get access token
        if (isset($get['code'])) {

            $result = DatabaseHandler::retrive_db_fields('#__oauth_client_settings', '*', 'id', 1, 0, 'loadobjectlist');
            $oauth_access_token = OAuthauthenticate::call_to_token_endpoint($result['token_endpoint_url'], JURI::root(),  $result['client_id'], $result['client_secret'], $get['code'], 'authorization_code');
        }

        //Get userinfo
        if (isset($oauth_access_token))
            $user_info = OAuthauthenticate::call_to_user_info_endpoint($result['userinfo_endpoint_url'], $oauth_access_token);


        // Create or login user into the Joomla
        if (isset($user_info))
            $this->create_or_login_user($user_info);
    }

    public function onAfterInitialise()
    {

        //

    }

    public function create_or_login_user($user_info)
    {

        $result = DatabaseHandler::retrive_db_fields('#__oauth_attributeconfig', '*', 'id', 1, 0, 'loadobjectlist');


        $userid = JFactory::getUser($user_info['given_name']);
        //If need to retrive user using email use below code
        //    jimport('joomla.user.helper');
        //     userId = JUserHelper::getUserId($email); // Will not work



        if ($userid->id) {

            // Instantiate the application.
            $app = JFactory::getApplication('site');
            $app->initialise();

            jimport('joomla.user.authentication');
            $authenticate = JAuthentication::getInstance();
            $response = new JAuthenticationResponse();

            $user = JUser::getInstance($userid->id);
            $session = JFactory::getSession();

            $user->set('block', '0');
            $user->set('activation', '');
            $user->save();

            $response->status == JAuthentication::STATUS_SUCCESS;
            $session->set('user', $user);

            // SSO OAuth Login flag
            $session->set('oauthclient_login', 1);

            $app->redirect(JURI::root() . 'index.php?', "Welcome $user->username", 'message');
       
	   } else {
			
			
               jimport('joomla.user.helper');
				$data = array(
					"name"=>$user_info['given_name'],
					"username"=>$user_info['given_name'],
					"password"=>'',
					"password2"=>'',
					"email"=>$user_info['email'],
					"block"=>0,
					"groups"=>array("1","2")
				);

				$user = new JUser;
				//Write to database
				if(!$user->bind($data)) {
					throw new Exception("Could not bind data. Error: " . $user->getError());
				}
				if (!$user->save()) {
					throw new Exception("Could not save user. Error: " . $user->getError());
				}

			         
		}
   

   }
	
	
}
